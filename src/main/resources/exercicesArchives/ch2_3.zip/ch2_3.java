/* Chapitre 2: Section 2, notre Shape3D
 * Auteur    : daboul 
 * Date      : 03/00
 * 
 */


//Java standart API
import java.awt.Frame;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.BorderLayout;
//Java3d API
import com.sun.j3d.utils.universe.SimpleUniverse;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.TransformGroup;
import javax.media.j3d.Transform3D;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Appearance;
import javax.media.j3d.Geometry;
import javax.media.j3d.TriangleStripArray;
import javax.media.j3d.PolygonAttributes;
import javax.vecmath.Point3f;
import javax.vecmath.Color3f;
import javax.vecmath.Vector3f;

class ch2_3 extends Frame implements WindowListener
{
	ch2_3()
	{
		super("- Chapitre 2 : notre Shape3D -");
		this.addWindowListener(this);
		this.setLayout(new BorderLayout());
		
		//creation de la scene java3d
		Canvas3D canvas=new Canvas3D(SimpleUniverse.getPreferredConfiguration());
		SimpleUniverse myWorld=new SimpleUniverse(canvas);
		BranchGroup myScene=createScene();
		myWorld.addBranchGraph(myScene);
		myWorld.getViewingPlatform().setNominalViewingTransform();
				
		this.add("Center",canvas);
	}
	
	BranchGroup createScene()
	{
		BranchGroup scene=new BranchGroup();
		
		Transform3D t3d=new Transform3D();
		t3d.setTranslation(new Vector3f(0f,-0.4f,0f));
		TransformGroup tg=new TransformGroup(t3d);
		
		Shape3D shape=new Shape3D(mkGeometry0(0.5f,0.85f,0.8f,25,new Color3f(1f,0f,1f)),createApp("LINE"));
		
		tg.addChild(shape);
		scene.addChild(tg);
		
		scene.compile();
		return scene;
	}
	
	private Geometry mkGeometry0(float radius1,float radius2,float height,int nbPane,Color3f color)
	{
		int tab[]=new int[1];
		tab[0]=(nbPane*2)+2;
		TriangleStripArray geom0=new TriangleStripArray
			((nbPane*2)+2
			,TriangleStripArray.COORDINATES|TriangleStripArray.COLOR_3
			,tab);
		Color3f blue=new Color3f(0f,0f,1f);
		Color3f yellow=new Color3f(1f,1f,0f);
		
		for(int i=0;i<(nbPane*2)+2;i++) geom0.setColor(i,color);  
		
		double angle=2*Math.PI/nbPane;
		
		Point3f point=new Point3f();
		for(int i=0;i<nbPane;i++)
		{
			if (i==0)
			{
				point.x=(float)(radius1*Math.cos(0*angle));
				point.y=(float)height;
				point.z=(float)(radius1*Math.sin(0*angle));
				geom0.setCoordinate(0,point);
				
				point.x=(float)(radius2*Math.cos(0*angle));
				point.y=0f;
				point.z=(float)(radius2*Math.sin(0*angle));
				geom0.setCoordinate(1,point);
				
				point.x=(float)(radius1*Math.cos(1*angle));
				point.y=(float)height;
				point.z=(float)(radius1*Math.sin(1*angle));
				geom0.setCoordinate(2,point);
				
				point.x=(float)(radius2*Math.cos(1*angle));
				point.y=0f;
				point.z=(float)(radius2*Math.sin(1*angle));
				geom0.setCoordinate(3,point);
			}
			else
			{
				point.x=(float)(radius1*Math.cos((i+1)*angle));
				point.y=(float)height;
				point.z=(float)(radius1*Math.sin((i+1)*angle));
				geom0.setCoordinate((i+1)*2,point);
				
				point.x=(float)(radius2*Math.cos((i+1)*angle));
				point.y=0f;
				point.z=(float)(radius2*Math.sin((i+1)*angle));
				geom0.setCoordinate((i+1)*2+1,point);
			} 
		}
						
		return geom0;
	}
	
	private Appearance createApp(String str)
	{
		Appearance app=new Appearance();
        	PolygonAttributes polyAttrib = new PolygonAttributes();
            	polyAttrib.setCullFace(PolygonAttributes.CULL_NONE);
            	if (str.equals("LINE")) polyAttrib.setPolygonMode(PolygonAttributes.POLYGON_LINE);
            	app.setPolygonAttributes(polyAttrib);
        	
        	return app;
	}
		
	//fonctions de gestion des evenements window
	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}
	
	public void windowClosing(WindowEvent e)
	{
		System.exit(1);
	}
	
	public static void main(String args[])
	{
		ch2_3 myApp=new ch2_3();
		myApp.setSize(400,400);
		myApp.setVisible(true);
	}
}

