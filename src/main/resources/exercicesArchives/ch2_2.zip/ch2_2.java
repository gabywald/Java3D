/* Chapitre 2: Section 2 cr�ation d'une lampe
 * Auteur    : daboul 
 * Date      : 03/00
 */


//Java standart API
import java.awt.Frame;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.BorderLayout;
//Java3d API
import com.sun.j3d.utils.universe.SimpleUniverse;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.TransformGroup;
import javax.media.j3d.Transform3D;
import javax.vecmath.Vector3f;
//mes objets
import lampe;

class ch2_2 extends Frame implements WindowListener
{
	ch2_2()
	{
		super("- Chapitre 2 : cr�ation de la lampe -");
		this.addWindowListener(this);
		this.setLayout(new BorderLayout());
		
		//creation de la scene java3d
		Canvas3D canvas=new Canvas3D(SimpleUniverse.getPreferredConfiguration());
		SimpleUniverse myWorld=new SimpleUniverse(canvas);
		BranchGroup myScene=createScene();
		myWorld.addBranchGraph(myScene);
		myWorld.getViewingPlatform().setNominalViewingTransform();
				
		this.add("Center",canvas);
	}
	
	BranchGroup createScene()
	{
		BranchGroup scene=new BranchGroup();
		
		Transform3D t3d=new Transform3D();
		t3d.setScale(0.65f);
		TransformGroup tg=new TransformGroup(t3d);
		
		lampe lp0=new lampe(this,new Vector3f(-0.9f,-0.1f,0f));
		tg.addChild(lp0.createLampe("LINE","LINE","LINE"));
		
		lampe lp1=new lampe(this,new Vector3f(0f,-0.1f,0f));
		tg.addChild(lp1.createLampe("LINE","",""));
		
		lampe lp2=new lampe(this,new Vector3f(0.9f,-0.1f,0f));
		tg.addChild(lp2.createLampe("","",""));
		
		scene.addChild(tg);
		
		scene.compile();
		return scene;
	}
		
	//fonctions de gestion des evenements window
	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}
	
	public void windowClosing(WindowEvent e)
	{
		System.exit(1);
	}
	
	public static void main(String args[])
	{
		ch2_2 myApp=new ch2_2();
		myApp.setSize(500,300);
		myApp.setVisible(true);
	}
}

